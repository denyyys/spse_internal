# qBittorrent Icons

## Color Reference
Colors have been selected from Qt documented [SVG Colors](https://doc.qt.io/qt-6/qcolorconstants.html#svg-colors). It is recommended to use color Hex from the given source.
