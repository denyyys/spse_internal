<!DOCTYPE html>
<html>
<head>
    <title>Whonnock - O nás</title>
    <meta charset="UTF-8">
    <link rel="icon" href="favicon.png">
    <link rel="stylesheet" href="style2.css">
</head>
<p>
<h1><p class="solid">
        Whonnock Servers</h1></p>
<ul>
    <li><a href="index.php">Hlavní</a></li>
    <li><a href="administrace.php">Administrace</a></li>
    <li><a href="cenik.php">Ceník</a></li>
    <li><a href="aktuality.php">Aktuality</a></li>
    <li style="float:right"><a class="active" href="onas.php">O nás</a></li>
</ul>

<img src="icon.jpeg" width="300px" height="300px" style="float:right"  alt="logo"/>
<h2>
    O nás
</h2>
<h3>
    Jsme vcelku malá firma, která se stará o plynulý běh Vašich serverových požadavků.<br>
    Začali jsme jako startup v březnu roku 2022 a nejspíš jako startup taky zůstanem.<br><br>
    Důvodem našich občasných výpadků či špatně zpracovaných požadavků je náš developer.<br>
    Našim hlavním developerem je podprůměrné ochotný student, kterého kdybychom platili,<br>
    tak možná bychom se nějakých výsledků i dočkali. <br><br>
    I přesto vše, jsme za náš tým rádi a věříme v brzký vzrůst naší firmy!<br>
</h3>

<br><br>
<center>
<h2>
    Tým
</h2>

<h4>
    Výkonný ředitel
</h4>
<h3>
    - Nespecifikováno
</h3>
<h4>
    Hlavní developer
</h4>
<h3>
    - Denis Mynaří
</h3>

</center>




</body>
</html>
