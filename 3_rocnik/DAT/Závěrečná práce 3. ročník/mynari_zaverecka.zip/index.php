<!DOCTYPE html>
<html>
    <head>
        <title>Whonnock</title>
         <meta charset="UTF-8">
         <link rel="icon" href="favicon.png">
         <link rel="stylesheet" href="style1.css">
    </head>
    <body>
    <p>
    <h1><p class="solid">
        Whonnock Servers</h1></p>
    <ul>
        <li><a href="index.php">Hlavní</a></li>
        <li><a href="administrace.php">Administrace</a></li>
        <li><a href="cenik.php">Ceník</a></li>
        <li><a href="aktuality.php">Aktuality</a></li>
        <li style="float:right"><a class="active" href="onas.php">O nás</a></li>
    </ul>

        <img src="icon.jpeg" width="300px" height="300px" style="float:right"  alt="logo"/>
    <h2>
        Hlavní stránka
    </h2>
    <h3>
        Vítáme Vás na oficiálním webu společnosti Whonnock Servers!<br>
        Nabízíme stabilní a ekonomické řešení pro Vaše serverové potřeby.<br><br>
        Odtud také můžete spravovat Vaše pronajmuté servery.<br>
        V záložce Administrace spravujte své servery.<br><br>

    </h3>




    </body>
</html>
