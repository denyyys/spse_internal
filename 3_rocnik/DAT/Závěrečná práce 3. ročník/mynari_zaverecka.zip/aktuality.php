<!DOCTYPE html>
<html>
    <head>
        <title>Whonnock - Ceník</title>
         <meta charset="UTF-8">
         <link rel="icon" href="favicon.png">
         <link rel="stylesheet" href="style5.css">
    </head>
    <body>
    <p>
    <h1><p class="solid">
        Whonnock Servers</h1></p>
    <ul>
        <li><a href="index.php">Hlavní</a></li>
        <li><a href="administrace.php">Administrace</a></li>
        <li><a href="cenik.php">Ceník</a></li>
        <li><a href="aktuality.php">Aktuality</a></li>
        <li style="float:right"><a class="active" href="onas.php">O nás</a></li>
    </ul>

        <img src="icon.jpeg" width="300px" height="300px" style="float:right"  alt="logo"/>
    <h2>
        Aktuality
    </h2>


<h3>
  Tu už se asi nic nezmění.<br>


</h3>






    </body>
</html>
