<html>
<head>
<title>21_03_2022</title>
<body>
<h1>Zápis do souboru</h1>
<h2>21.03.2022</h2>



  <form action="21032022skript.php" method="post">
  <fieldset>
  <legend>Zadej Data:</legend>
  <label></label><input type="text" name="jmeno" placeholder="Jméno" required><br>
  <label></label><input type="text" name="prijmeni" placeholder="Příjmení" required><br>
  <label></label><input type="text" name="email" placeholder="email@email.cz" required><br>
  <input type="submit" name="submit" value="Odeslat">
  </form>
  </fieldset>
  
  <form action ="21032022vypis.php" method="post">
  <legend>Čtení dat:</legend>
  <input type="submit" name="submit" value="Čtení">
  




</body>
</html>