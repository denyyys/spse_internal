#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<windows.h>

#define N 100

int poleA[N];

void nacteni(int poleA[],int pocet);
void nacteni_rand(int poleA[],int pocet);
void vypis(int poleA[],int pocet);
int nejmensi(int poleA[],int pocet);
int nejvetsi(int poleA[],int pocet);
float prumer(int poleA[],int pocet);
int pridani(int poleA[],int pocet,int x);
int pridaniPoz(int poleA[],int pocet,int x,int pozp);
int zruseni(int poleA[],int pocet,int pozz);

int main()
{
	int volba,pocet,o=1,x,pozp,pozz;
	do
	{
		printf("Vyberte z moznosti:\n");
		printf("0.KONEC\n");
		printf("1.Nacteni pole\n");
		printf("2.Nacteni pole nahodnymi cisly\n");
		printf("3.Vypis pole\n");
		printf("4.Nejmensi cislo\n");
		printf("5.Nejvetsi cislo\n");
		printf("6.Prumer\n");
		printf("7.Pridani prvku do pole\n");
		printf("8.Pridani prvku do pole na danou pozici\n");
		printf("9.Zruseni prvku v poli na dane pozici\n");
	
		scanf("%d",&volba);
	
	
		switch(volba)
		{
			case 0: o=0;
					break;
					
			case 1: system("cls");
					printf("Zadejte pocet hodnot\n");
					scanf("%d",&pocet);
					nacteni(poleA,pocet);
					system("cls");
					break;
					
			case 2: system("cls");
					printf("Zadejte pocet hodnot:\n");
					scanf("%d",&pocet);
					nacteni_rand(poleA,pocet);
					system("cls");
					break;
					
			case 3: system("cls");
					printf("Zde jsou vase cisla:\n");
					vypis(poleA,pocet);
					break;
					
			case 4: system("cls");
					printf("Zde je nejmensi cislo: %d\n",nejmensi(poleA,pocet));
					system("pause");
					system("cls");
					break;
					
			case 5: system("cls");
					printf("Zde je nejvetsi cislo: %d\n",nejvetsi(poleA,pocet));
					system("pause");
					system("cls");
					break;
					
			case 6: system("cls");
					printf("Zde je prumer vsech cisel: %.2f\n",prumer(poleA,pocet));
					system("pause");
					system("cls");
					break;
					
			case 7: system("cls");
					printf("Zadejte cislo ktere chcete pridat:\n");
					scanf("%d",&x);
					pocet=pridani(poleA,pocet,x);
					vypis(poleA,pocet);
					system("pause");
					system("cls");
					break;
					
			case 8: system("cls");
					printf("Zadejte pozici:\n");
					scanf("%d",&pozp);
					if(pozp>pocet-1)
					{
						printf("Zadali jste neplatnou pozici\n");
						system("pause");
						system("cls");
						break;
					}
					else
					{
					printf("Zadejte cislo ktere chcete pridat:\n");
					scanf("%d",&x);
					pocet=pridaniPoz(poleA,pocet,x,pozp);
					system("cls");
					printf("Zde je vase pole:\n");
					vypis(poleA,pocet);
					system("pause");
					system("cls");
					break;
					}
					
			case 9: system("cls");
					printf("Zadejte pozici ze ktere chcete vymazat cislo:\n");
					scanf("%d",&pozz);
					if(pozz>pocet-1)
					{
						printf("Zadali jste neplatnou pozici\n");
						system("pause");
						system("cls");
						break;
					}
					else
					{
					pocet=zruseni(poleA,pocet,pozz);
					system("cls");
					printf("Zde je vase pole:\n");
					vypis(poleA,pocet);
					system("pause");
					system("cls");
					break;
					}
		}
	
	
	
	}while(o==1);
	return 0;
}

void nacteni(int poleA[],int pocet)
{
	int i;
	for(i=0;i<pocet;i++)
	{
		printf("Zadejte cislo\n");
		scanf("%d",&poleA[i]);
	}
}

void nacteni_rand(int poleA[],int pocet)
{
	int i;
	srand(time(NULL));
	
	for(i=0;i<pocet;i++)
	{
		poleA[i]=rand()%100;
	}
	
}

void vypis(int poleA[],int pocet)
{
	int i;
	for(i=0;i<pocet;i++)
	{
		printf("%d\n",poleA[i]);
	}
	system("pause");
	system("cls");
}

int nejmensi(int poleA[],int pocet)
{
	int i,nejmensi=0;
	
	nejmensi=poleA[0];
	
	for(i=0;i<pocet;i++)
	{
		printf("%d\n",poleA[i]);
	}
	
	for(i=0;i<pocet;i++)
	{
		if(poleA[i]<nejmensi)
		{
			nejmensi=poleA[i];
		}
		
	}
	return nejmensi;
}

int nejvetsi(int poleA[],int pocet)
{
	int i,nejvetsi=0;
	
	nejvetsi=poleA[0];
	
	for(i=0;i<pocet;i++)
	{
		printf("%d\n",poleA[i]);
	}
	
	for(i=0;i<pocet;i++)
	{
		if(poleA[i]>nejvetsi)
		{
			nejvetsi=poleA[i];
		}
		
	}
	return nejvetsi;
}

float prumer(int poleA[],int pocet)
{
	int i,soucet=0;
	float prmr;
	
	for(i=0;i<pocet;i++)
	{
		soucet=soucet+poleA[i];
	}
	
	prmr=(float)soucet/pocet;
	
	return prmr;
}

int pridani(int poleA[],int pocet,int x)
{
	poleA[pocet]=x;
	pocet=pocet+1;
	
	return pocet;
}

int pridaniPoz(int poleA[],int pocet,int x,int pozp)
{
	int i;
	
	for(i=pocet-1;i>pozp-1;i--)
	{
		poleA[i+1]=poleA[i];
	}
	poleA[pozp]=x;
	
	pocet=pocet+1;
	
	return pocet;
}

int zruseni(int poleA[],int pocet,int pozz)
{
	int i;
	
	for(i=pozz;i<pocet;i++)
	{
		poleA[i]=poleA[i+1];
	}
	
	pocet=pocet-1;
	
	return pocet;
}
