// zadani = tlacitko -> port  D nebo port E
#include "stm32f4xx.h"                  // Device header
void Delay (uint32_t ms);

int main()
{
	int tlacitko;
	RCC ->AHB1ENR |= (1UL << 3); // port D
	RCC ->AHB1ENR |= (1UL << 4);
	RCC->AHB1ENR |= (1UL << 0);
	GPIOD->MODER |= (1UL << 2*12);
	GPIOE->MODER |= (1UL << 2*13);
	
	while(1){
		tlacitko=GPIOA->IDR;
		
		tlacitko&=1;
		
		if(tlacitko==1)
			{
			GPIOD->ODR |= (1UL << 12); //roznuti ledky D
			GPIOD->ODR &=~ (1UL << 12); //zhasnuti D
			GPIOE->ODR |= (1UL << 13); //roznuti ledky E
			}	
			if(tlacitko==1)
			{
				GPIOD->ODR &=~ (1UL << 13); //zhasnuti E
				GPIOD->ODR |= (1UL << 12); //roznuti ledky D
			}
			
		}
		return 0;
	}
	
	
	

