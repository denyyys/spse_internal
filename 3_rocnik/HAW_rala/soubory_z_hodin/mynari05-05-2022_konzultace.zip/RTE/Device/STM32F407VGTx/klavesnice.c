#include "stm32f4xx.h"                  // Device header
#include <stdio.h>
#include <stdlib.h>


void SysTick_Handler(void);
uint8_t getkey();
void LCD_config(void);
void LCD_ini(void);
void puts_LCD(int radek, char* ukaz);
void klavesnice_config(void);


int main(){
	uint8_t klavesa, prvni, druhe;
	char x[1];
	
	SystemCoreClockUpdate();
	SysTick_Config(SystemCoreClock/10000);
	LCD_config();
	LCD_ini();
	klavesnice_config();
	
	while(1)
	{
		do{
			klavesa = getkey();
			if(klavesa == '#'){
				break;
			}
			else{
				prvni = klavesa;
				sprintf(,"%d",prvni);
				puts_LCD(1,x);
			}
		
	
	}while(klavesa!='#');

	return 0;
}
	}
